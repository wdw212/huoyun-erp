import{T as t}from"./index-B2O--RwP.js";const r=e=>t({url:"/select-options/"+e,method:"get"});export{r as g};
